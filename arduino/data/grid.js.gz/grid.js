/**
 * Zjednodusene pouziti css wizardry grid.
 *
 * @author Pavel Petrzela
 * @version $Revision: 1.6 $ $Date: 2018/05/04 09:54:00 $
*/

// Fix pro IE, neni tam startsWith
if (!String.prototype.startsWith) {
  String.prototype.startsWith = function(searchString, position) {
    position = position || 0;
    return this.indexOf(searchString, position) === position;
  };
}

var gridapp = angular.module ("G2Grid", []);


function remapGridClass (s) {
  var cn = s;
  var resl;

  if (cn.startsWith ("palm-")) {
    resl = "palm--";
    cn = cn.substring (5);
  } else if (cn.startsWith ("lap-")) {
    resl = "lap--";
    cn = cn.substring (4);
  } else if (cn.startsWith ("portable-")) {
    resl = "portable--";
    cn = cn.substring (9);
  } else {
    resl = "";
  }

  switch (cn) {
    case "0" : case "hidden" : resl += "hidden"; break;
    case "1" : case "1/1" : case "whole" : resl += "one-whole"; break;
    case "1/2" : case "2/4" : case "3/6" : case "4/8" : case "5/10" : case "6/12" : resl += "one-half"; break;
    case "1/3" : case "2/6" : case "4/12" : resl += "one-third"; break;
    case "2/3" : case "4/6" : case "8/12" : resl += "two-thirds"; break;
    case "1/4" : case "2/8" : case "3/12" : resl += "one-quarter"; break;
    case "3/4" : case "6/8" : case "8/12" : resl += "three-quarters"; break;
    case "1/5" : case "2/10" : resl += "one-fifth"; break;
    case "2/5" : case "4/10" : resl += "two-fifths"; break;
    case "3/5" : case "6/10" : resl += "three-fifths"; break;
    case "4/5" : case "8/10" : resl += "four-fifths"; break;
    case "1/6" : case "2/12" : resl += "one-sixth"; break;
    case "5/6" : case "10/12" : resl += "five-sixths"; break;
    case "1/8" : resl += "one-eight"; break;
    case "3/8" : resl += "three-eights"; break;
    case "5/8" : resl += "five-eights"; break;
    case "7/8" : resl += "seven-eights"; break;
    case "1/9" : resl += "one-ninth"; break;
    case "2/9" : resl += "two-ninths"; break;
    case "4/9" : resl += "four-ninths"; break;
    case "5/9" : resl += "five-ninths"; break;
    case "7/9" : resl += "seven-ninths"; break;
    case "8/9" : resl += "eight-ninths"; break;
    case "1/10" : resl += "one-tenth"; break;
    case "3/10" : resl += "three-tenths"; break;
    case "7/10" : resl += "seven-tenths"; break;
    case "9/10" : resl += "nine-tenths"; break;
    case "1/12" : resl += "one-twelfth"; break;
    case "5/12" : resl += "five-twelfths"; break;
    case "7/12" : resl += "seven-twelfths"; break;
    case "11/12" : resl += "eleven-twelfths"; break;
    default : throw "Unexpected style " + cn + "!";
  }

  return resl;
}

// Shorthand pro <div class="grid">....
// Pouziti: <div g>...</div>
gridapp.directive ("g", function() {
  return {
    restrict : "A",
    link : function (scope, element, attrs) {
      var oc = attrs["class"];

      element.attr ("class", (oc ? oc + " " : "") + "grid g2Panel");
    }
  }
});

// Shorthand pro <div class="grid__item..."
// V hodnote gi=? muzou byt ciselne zlomky velikosti dle mapovani v remapGridClass
// Pouziti: <div gi>...</div> nebo napr. <div gi="1/3 lap-1/2 palm-0">...</div>
gridapp.directive ("gi", function() {
  return {
    restrict : "A",
    link : function (scope, element, attrs) {
      var d = attrs["gi"];
      var oc = attrs["class"];

      var classNames = "grid__item g2Panel";
      if (d) {
        var x = d.split (' ');
        for (var i = 0; i < x.length; i++) {
          classNames += " " + remapGridClass (x[i]);
        }
      }
      element.attr ("class", (oc ? oc + " " : "") + classNames);
    }
  }
});

// Shorthand pro zamezeni standardniho 5px padovani gridu
gridapp.directive ("nopad", function() {
  return {
    restrict : "A",
    link : function (scope, element, attrs) {
      var oc = attrs["style"];
      element.attr ("style", (oc ? oc + " " : "") + "padding:0;");
    }
  }
});


// Spolecny styl pro hlavni element aplikace; zajisti maximalni sirku 1024px a centrovani aplikace
// Potomci elementu se ocekavaji jako grid__item.
// Pouziti: <div g2angular ng-controller="...">...</div>
gridapp.directive ("g2angular", function() {
  return {
    restrict : "A",
    link : function (scope, element, attrs) {
      var oc = attrs["style"];
      var cl = attrs["class"];

      element.attr ("style", (oc ? oc + " " : "") + "padding:0; max-width: 1024px; margin-left: auto; margin-right: auto;");
      element.attr ("class", (cl ? cl + " " : "") + "grid g2Panel");
    }
  }
});

